package com.javaproject1.springboot1backend;

import com.javaproject1.springboot1backend.model.Employee;
import com.javaproject1.springboot1backend.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot1BackendApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Springboot1BackendApplication.class, args);
	}


	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public void run(String... args) throws Exception {
		Employee employee = new Employee();
		employee.setFirstName("sujana");
		employee.setLastName("sr");
		employee.setEmailId("sujana@gmail.com");
		employeeRepository.save(employee);


		Employee employee1 = new Employee();
		employee1.setFirstName("vishnu");
		employee1.setLastName("sar");
		employee1.setEmailId("vishnusar200@gmail.com");
		employeeRepository.save(employee1);
	}
}
