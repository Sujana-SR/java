package com.javaproject1.springboot1backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot1BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
