package com.jspdemo.Controller;

import com.jspdemo.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class Controllers {

    @Autowired
    Model model;
    @RequestMapping("/home")
    public String home() {
        return "Home";
    }

    @RequestMapping("/form")
    public String form() {
        return "form";
    }
    @RequestMapping("/save")
    public String save(@ModelAttribute("student") Employee student ){
        System.out.println(student.name);
        model.insert(student);
     return "completed";
    }
}
