package com.jspdemo.jspdemo.config;

import com.jspdemo.models.Model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
//import org.springframework.web.servlet.ModelAndView;

@Configuration
public class config {
    
   @Bean 
    public Model student1(){
        return new Model();
    }
}
