
package com.jspdemo;

public class Employee {
    int id;
    String firstName;
    String lastName;
   
   
    
    public Employee(int id, String firstName, String lastName) {
        this.id = id;
        this.firstName = lastName;
        this.lastName = lastName;
       
        
    }
}

