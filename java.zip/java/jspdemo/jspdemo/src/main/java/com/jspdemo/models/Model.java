package com.jspdemo.models;

import com.jspdemo.Employee;

import org.springframework.stereotype.Repository;

@Repository
public class Model {
  public void insert(Employee student) {

  }
}

