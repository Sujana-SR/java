package com.jspdemo.jspdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JspdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JspdemoApplication.class, args);
	}

}
