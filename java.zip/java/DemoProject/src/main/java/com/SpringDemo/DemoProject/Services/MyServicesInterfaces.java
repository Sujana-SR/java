package com.SpringDemo.DemoProject.Services;


import com.SpringDemo.DemoProject.Books;

import java.util.List;
public interface MyServicesInterfaces {
    public List<Books> getBooks();
    public Books addBook();
    public List<Books> getByid();
}
