package com.SpringDemo.DemoProject.Services;

import com.SpringDemo.DemoProject.Books;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class MyServices implements MyServicesInterfaces {

    List<Books> list = new ArrayList<Books>();

    public MyServices() {
        this.list.add(new Books(12, "java", "about java"));
        this.list.add(new Books(12, "python", "about java"));

    }

    @Override
    public List<Books> getBooks() {
        return list;
    }

    @Override
    public Books addBook(Books books) {
        this.list.add(books);
        return books;
    }

    @Override
    public Books getByid(int id) {
        for (Books books : this.list) {
            if (books.getId() == id) {
                return books;
            }
        }
        return null;
    }
}
