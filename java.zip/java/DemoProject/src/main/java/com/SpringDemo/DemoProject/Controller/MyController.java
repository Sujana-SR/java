package com.SpringDemo.DemoProject.Controller;


import com.SpringDemo.DemoProject.Services.MyServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {
    @Autowired
    MyServices myservices;
    @GetMapping("books")
    public List<Books> books(){
        return myservices.getBooks();

    }
    @PostMapping("addbook")
    public Books addBook(@RequestBody Books book){
        return myservices.addBook(book);
    }

}
