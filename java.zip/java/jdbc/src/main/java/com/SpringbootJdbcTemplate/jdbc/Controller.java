package com.SpringbootJdbcTemplate.jdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Controller {
    @Autowired
    Demo demo;

    @GetMapping(value = "/")
    public String index() {
        return "index";
    }

    @GetMapping(value = "studentnames")
    public List<String> studentnames() {
        return demo.getallStudentnames();
    }




    @PostMapping(value = "/login")
    public String Login(@RequestBody Login login) {
        System.out.println(login.getUsername());
        System.out.println(login.getPassword());
        return "login is done";
    }

    @GetMapping(value = "params")
    public String params(@RequestParam("name") String name, @RequestParam("pass") String paas) {
        return "hellow" + name;
    }

    @GetMapping(value = "header")
    public String header(@RequestHeader("name") String name, @RequestHeader("pass") String pass) {
        return "hellow" + name;
    }
}
