package com.example.demo;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Properties;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
	}
@Bean
public CommandLineRunner run(EmployeeRepository repository) {
		return (args -> {
			insertEmployeeData(repository);
		System.out.println(repository.findAll());
	});
}

	private void insertEmployeeData(EmployeeRepository repository){

	repository.save(new Employee("Sujana", "S R"));
	repository.save(new Employee("John", "Denver"));
	repository.save(new Employee("Max", "Cooper"));
	repository.save(new Employee("ben", "thompson"));
}
}
