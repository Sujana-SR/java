package com.SpringDemoCar.DemoProjectCar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProjectCarApplicationTests {

	@Test
	void contextLoads() {
	}

}
