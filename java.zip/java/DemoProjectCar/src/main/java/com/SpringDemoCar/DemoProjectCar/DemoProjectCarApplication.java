package com.SpringDemoCar.DemoProjectCar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProjectCarApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoProjectCarApplication.class, args);
	}

}
