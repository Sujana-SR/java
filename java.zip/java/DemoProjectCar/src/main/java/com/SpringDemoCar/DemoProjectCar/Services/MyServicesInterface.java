package com.SpringDemoCar.DemoProjectCar.Services;

import com.SpringDemoCar.DemoProjectCar.Cars;

import java.util.List;

public interface MyServicesInterface {
    public List<Cars> getCars();
    public Cars addCar(Cars cars);
    public Cars getBycarnum(int carnum);
}
