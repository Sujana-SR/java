package com.SpringDemoCar.DemoProjectCar.Services;


import com.SpringDemoCar.DemoProjectCar.Cars;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

    @Service
    public class MyServices implements MyServicesInterface {

        List<Cars> list = new ArrayList<>();

        public MyServices() {
            list.add(new Cars(123, "xuv", "high performance"));
            list.add(new Cars(121, "kuv", "high performance"));

        }

      @Override
        public List<Cars> getCars() {
            return list;
        }
        @Override
        public Cars addCar(Cars cars) {
            this.list.add(cars);
            return cars;
        }

        @Override
        public Cars getBycarnum(int carnum) {
            for (Cars cars : this.list) {
                if (cars.getCarnum() == carnum) {
                    return cars;
                }
            }
            return null;
        }
    }

