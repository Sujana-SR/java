package com.SpringDemoCar.DemoProjectCar.Controller;

import com.SpringDemoCar.DemoProjectCar.Cars;
import com.SpringDemoCar.DemoProjectCar.Services.MyServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyController {

    @Autowired
    MyServices myservices;
    @GetMapping("cars")
    public List<Cars> cars(){
        return myservices.getCars();

    }
    @PostMapping("addCar")
    public Cars addCar(@RequestBody Cars car){
        return myservices.addCar(car);
    }

    @GetMapping("carbynum")
    public Cars carBycarnum(@RequestParam("carnum") int carnum) {
        return myservices.getBycarnum(carnum);
    }

}
