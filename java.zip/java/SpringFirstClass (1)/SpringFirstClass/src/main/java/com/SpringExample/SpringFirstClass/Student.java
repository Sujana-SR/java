package com.SpringExample.SpringFirstClass;

import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Statement;

public class Student {
    @Autowired
    College college;

    @Autowired
    Statement stm;

    public String studentname() {
        return "you are in student class inside studentname function ===" + college.collegename();
    }
    public String studentcollege(){
        return "you are in student class inside studentcollege function";
    }
}
