package com.SpringExample.SpringFirstClass;


import org.springframework.stereotype.Component;

@Component
public class Demo {

    public Demo(){

    }
    public String demoin(){
        return "you are in demo class";
    }
}
