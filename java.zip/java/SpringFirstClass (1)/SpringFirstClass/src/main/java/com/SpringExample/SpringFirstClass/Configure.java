package com.SpringExample.SpringFirstClass;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

@Configuration
public class Configure {
    @Bean
    public Student student(){
        return new Student();
    }
    @Bean
    public College college(){
        return new College();
    }
   // @Value("{$mysql.url}")
     //       String url;
    String url="jdbc:msql://localhost:3306/demo";
    String username="root";
    String pass="root";

    @Bean
    public Statement jdbc() throws SQLException{
        return DriverManager.getConnection(url,username,pass).createStatement()
    }
}
