package com.SpringExample.SpringFirstClass.Controllers;
import com.SpringExample.SpringFirstClass.College;
import com.SpringExample.SpringFirstClass.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

@Autowired
Student student;

@Autowired
    College college;

@RequestMapping(value="/studentname")
public String name(){
    return student.studentname();
}
@RequestMapping(value="/collegename")
    public String collegename(){
    return college.collegename();
}
@RequestMapping(value="about")
    public String about() { return "you are in about page "}

}