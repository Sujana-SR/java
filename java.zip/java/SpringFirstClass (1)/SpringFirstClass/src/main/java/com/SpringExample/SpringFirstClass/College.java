package com.SpringExample.SpringFirstClass;

import org.springframework.beans.factory.annotation.Autowired;

import java.sql.Connection;
import java.sql.Statement;

public class College {

    @Autowired
    Statement stm;
    public String collegename() {
        String sql="select * from college";
        stm.executeQuery(sql);
        return "you are in college class inside collegename function";
    }
    public String collegebranch(){
        return "you are in college class inside collegebranch function ";

    }
}
